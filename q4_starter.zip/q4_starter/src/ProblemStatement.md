### Refactor the React app to use Routing instead of Conditional Rendering.

Display the Home, List and Contact pages using Client Side Routing instead of Condtional Rendering.

Note: The Home page should render on "/", List page on "/list" and Contact page on "/contact" route.

Expected Output:
<img src="https://files.codingninjas.in/demo-routing-app-26131.gif"/>
